# Lake Website 🌊

Simple lake-themed website project.

## Features
- Calm blue UI inspired by lakes
- Basic JavaScript interaction
- Clean layout

## How to Run
Open `index.html` in your browser.

## Author
Your Name
