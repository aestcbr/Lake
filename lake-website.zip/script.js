function showMessage() {
    alert("Welcome to the peaceful lake 🌊");
}
